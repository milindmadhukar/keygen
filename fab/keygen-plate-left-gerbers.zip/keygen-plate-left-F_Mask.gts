G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*
G04 #@! TF.CreationDate,2026-10-22T14:47:47+05:30*
G04 #@! TF.ProjectId,keygen-plate-left,6b657967-656e-42d7-906c-6174652d6c65,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-10-22 14:47:47*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H101*
X114294000Y-135575700D03*
G04 #@! TD*
G04 #@! TO.C,H102*
X34794000Y-161075700D03*
G04 #@! TD*
G04 #@! TO.C,H104*
X166294000Y-196575700D03*
G04 #@! TD*
G04 #@! TO.C,H103*
X182294000Y-89075700D03*
G04 #@! TD*
G04 #@! TO.C,H105*
X53794000Y-84075700D03*
G04 #@! TD*
M02*
