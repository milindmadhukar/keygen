G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.7*
G04 #@! TF.CreationDate,2026-10-22T20:28:29+05:30*
G04 #@! TF.ProjectId,keygen-plate-right,6b657967-656e-42d7-906c-6174652d7269,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.7) date 2026-10-22 20:28:29*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.200000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H203*
X258049899Y-194075700D03*
G04 #@! TD*
G04 #@! TO.C,H202*
X241549900Y-88575700D03*
G04 #@! TD*
G04 #@! TO.C,H204*
X388549900Y-161075700D03*
G04 #@! TD*
G04 #@! TO.C,H205*
X371049900Y-84575700D03*
G04 #@! TD*
G04 #@! TO.C,H201*
X315049900Y-133075700D03*
G04 #@! TD*
M02*
